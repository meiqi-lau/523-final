
function coffeeSelection(coffeeID) {
  console.log(coffeeID);
  window.localStorage.setItem("coffeeChoice", coffeeID);}




